def list_destinations(client_mqtt):
    # client_mqtt.
    pass
